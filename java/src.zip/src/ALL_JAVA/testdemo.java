package ALL_JAVA;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class testdemo {
public static void main(String a[]) throws FileNotFoundException{
	int n[][]= {
		      {1,2,3}, 
		      {4,5,6}, 
		      {3,6,7}, 
		};
	
for(int i=0;i<n.length;i++){
	for(int j=0;j<n.length;j++){
		if(i==j){
		//System.out.print(n[i][j]);
		}
		
		if(i+j==2){
			System.out.print(n[i][j]);
		}
	}
	
	System.out.println();
}
}
}
