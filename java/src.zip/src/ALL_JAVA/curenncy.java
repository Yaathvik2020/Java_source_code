package ALL_JAVA;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class curenncy {
public static void main(String a[]) {
	String st="rs123,45,6.7 8";	
	//st=st.replaceAll("[rs$,]", "");
	st=st.replaceAll("rs", "").replace(",", "").replaceAll("\\s+", "");
	double n=Double.parseDouble(st);
	System.out.println(n);
	//--------------------------------------------
	String s = "$123,456.7 8";
	  StringBuilder t = new StringBuilder();
	  for ( int i = 0; i < s.length(); i++ ) {
	    char ch = s.charAt(i);
	    if ( Character.isDigit(ch)||ch=='.') {
	      t.append(ch);
	    }
	  }
	  System.out.println(t);
	  	  //--------------------------------------------
	  //----------------------------------------------------------
	  String x="19.823.56 7,10 kr";
      x=x.replace(".","");
      x=x.replaceAll("\\s+","");
      x=x.replace(",", ".");
      x=x.replaceAll("[^0-9 , .]", "");
      System.out.println(x);
}
}
