  package ALL_JAVA;


public class clas {
	     public static void main(String a[]){
	    
	     }
}