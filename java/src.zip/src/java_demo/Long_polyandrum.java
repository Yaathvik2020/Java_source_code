package java_demo;

public class Long_polyandrum {
	public static String getLongestPalindrome( String in) {
		 String ln="";
		 for(int i=0;i<in.length();i++){
			 String n=interPalindrome(in,i,i);//11
			// System.out.print(n+"odd");
			 if(n.length()>ln.length()){
				 ln=n;
			 }

			 //
			   n=interPalindrome(in,i,i+1);//12
			  //System.out.print(n+"even");
			 if(n.length()>ln.length()){
				 ln=n;//
			 }
		 }
		 return ln;//
	}
	public static String interPalindrome(String in, int l,int r) {// 0 1// 4545445
		 while (l>=0&& r<in.length()&&in.charAt(l)==in.charAt(r)){
			  
			  l--;//0
			  r++;//2
		 }
		System.out.print(in.substring(l+1,r)+" ");
		 return in.substring(l+1,r);
	}
   public static void main(String ... args) {
       String str = "4545990989898445";
       String longestPali = getLongestPalindrome(str);
       System.out.println("String: " + str);
       System.out.println("Longest Palindrome: " + longestPali);
   }

}
