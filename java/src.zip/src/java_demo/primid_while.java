package java_demo;

public class primid_while {
	public static void main(String[] args){
		int n=5;
		int row=0;
		int spac=0;
		int k=0;
		while(row<n){
		 spac=n-row;
			row++;
			k=row;
			while (k>0){
				System.out.print(" ");
				k--;
			}
			if(spac%2==1){
			while(spac>0){
				System.out.print(" *");
				spac--;
			}
			}
			System.out.println();
		}
		 
	}
}
