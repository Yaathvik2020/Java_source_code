package java_demo;

import java.util.Scanner;
import java.util.Stack;

public class demo_d {
	public static void main(String a[]){
		Scanner sn=new Scanner(System.in);
		System.out.println("Enter the Input:");
		int n=sn.nextInt();
		Stack<Integer> s=new Stack<Integer>();
		
		while (n>0){
			int d=n%2;//011
			s.push(d);
			n=n/2;//3//1
		}
		while(!(s.isEmpty())){
			System.out.print(s.pop());
		}
		System.out.println("\n");
		//System.out.println(1%2);
	}

}
