package Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Array_list {
	public static void main(String arg[]){
	LinkedList a=new LinkedList();
		
		a.add("chinna");
		a.add("priya");
		a.add(1,"chinna");
		a.add(10);
		Iterator it=a.iterator();
//		while(it.hasNext()){
		System.out.println(a.get(2));
//		}
	
		for(Object ob:a){
			//System.out.println(ob);
		}
	}

}
