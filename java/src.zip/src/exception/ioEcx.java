package exception;

import java.io.IOException;

public class ioEcx {
	  static public void main(String a[]) throws IOException{
		  System.out.println("welcome"); 
		throw new IOException("input Error");
		  
	}

}
