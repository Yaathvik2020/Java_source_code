package FILE;

import java.util.HashSet;
import java.util.Set;

public class test {
	
	public static Set<String> permutationFinder(String str) {//c
        Set<String> perm = new HashSet<String>();
        //Handling error scenarios
        
          if (str.length() == 0) {//aac
            perm.add("");
            System.out.println("xxxx");
            return perm;
        }
          
        char initial = str.charAt(0); // first character a
        String rem = str.substring(1); // Full string without first character c
        Set<String> words = permutationFinder(rem);// 
        for (String strNew : words) {
        System.out.println(strNew+" test :"+strNew.length());
            for (int i = 0;i<=strNew.length();i++){
            	System.out.println(strNew+","+initial +","+i);//
            	//System.out.println(charInsert(strNew,initial,i)+":ME");
            	
                perm.add(charInsert(strNew,initial,i));//  "" ,c,0|c,b,0|c,b,1|Bc,a,0|bc,a,1|bc,a,2|
            }                                              
            											 
        }
          
        return perm;//b,ab,ba
      
          }
 
//
    public static String charInsert(String str, char c, int j) {// b,a,0
   	   	//System.out.println(str+" "+c+" "+j);
       String begin = str.substring(0, j);//0
        String end = str.substring(j);//b
        return begin + c + end; //ab
    }

    public static void main(String[] args) {
        String s = "ABC";
        
        System.out.println("\nPermutations for " + s + " are: \n" + permutationFinder(s));	}
}
